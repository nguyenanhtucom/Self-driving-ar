#!/usr/bin/env python
__author__ =  'Nguyen Anh Tu<info@nguyenanhtu.com>'
__version__=  '0.1'
__license__ = 'BSD'

import sys, time
import numpy as np
import cv2
import roslib
import rospy
from scipy.ndimage import filters
from sensor_msgs.msg import CompressedImage
#from cv_bridge import CvBridge, CvBridgeError
VERBOSE=False
class image_feature:
  def __init__(self):
 
    self.subscriber = rospy.Subscriber("team1/camera/depth/compressed", CompressedImage,self.callback_depth_image,  queue_size = 1)
    self.subscriber = rospy.Subscriber("team1/camera/rgb/compressed",CompressedImage, self.callback_compressed,  queue_size = 1)

    if VERBOSE :
      print "subscribed to team1/camera/rgb"

  def callback_depth_image(self, ros_data):
    np_arr = np.fromstring(ros_data.data, np.uint8)
    image_np = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    cv2.imshow('cv_depth', image_np)
    cv2.waitKey(2)

  def callback_compressed(self, ros_data):
    #print "callback_compressed"
    np_arr = np.fromstring(ros_data.data, np.uint8)
    image_np = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
    cv2.imshow('cv_img', image_np)
    cv2.waitKey(2)

def main(args):
  ic = image_feature()
  rospy.init_node('image_feature', anonymous=True)
  try:
    rospy.spin()
  except KeyboardInterrupt:
    print "Shutting down ROS Image feature detector module"
  cv2.destroyAllWindows()
  
if __name__ == '__main__':
  main(sys.argv)